
<?php
							
							
							$conn=mysqli_init();







mysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);






if (!$conn) {
    die('Not connected : ' . mysqli_connect_error());
}
	

									$sql = "SELECT * FROM  nodemcu ORDER BY id DESC";
									$result = mysqli_query($conn, $sql) or die( mysqli_error($conn));
 
 
	 
									while($res = mysqli_fetch_array($result)) {         
						
								$name=    $res['name'];
								$vid =	 $res['vid'] ;
								$time=	 $res['date'] ;
					         	$pid =	 $res['pid'] ;
					         	$sa =	 $res['sa'] ;
									
									 

									   }
									   
									  
				  
                                     
     ?>




<?php

 

$arr = array('name' => $name, 'vid' => $vid, 'time' => $time , 'status' => $sa  );

echo json_encode($arr);



?>