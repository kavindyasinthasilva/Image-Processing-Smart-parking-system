<?php


$conn=mysqli_init();

ysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);


if (!$conn) {
    die('Not connected : ' . mysqli_connect_error());
}



?>