
<?php
include_once 'header.php';
include_once 'locations_model.php';
?>


<div id="map"></div>

<!------ Include the above in your HEAD tag ---------->
<script>
    var map;
    var marker;
    var infowindow;
    var red_icon =  ' icon3.png' ;
    var purple_icon =  'icon2.png' ;
    var locations = <?php get_all_locations() ?>;
   
    function initMap() {
        var france = {lat:  6.785277702704765, lng: 80.11392854687506};
        infowindow = new google.maps.InfoWindow();
        map = new google.maps.Map(document.getElementById('map'), {
            center: france,
            zoom:   10,
            mapId: '8271b18eb74b62e4'
        });


        var i ; var confirmed = 0;
        for (i = 0; i < locations.length; i++) {

            marker = new google.maps.Marker({
                position: new google.maps.LatLng(locations[i][1], locations[i][2]),
                map: map,
                animation: google.maps.Animation.DROP,
                icon :   locations[i][7] === '1' ?  red_icon  : purple_icon,
                html: document.getElementById('form')
            });


         

            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                    confirmed =  locations[i][7] === '1' ?  'checked'  :  0;
                    $("#location_status").prop(confirmed,locations[i][7]);
                    $("#id").val(locations[i][0]);
                 
                    $("#email").val(locations[i][0]);
                    $("#phone").val(locations[i][1]);
                    
                    $("#city").val(locations[i][2]);
                    $("#category").val(locations[i][3]);
                    $("#amount").val(locations[i][4]);
                    $("#area").val(locations[i][5]);
                    $("#sky1").val(locations[i][6]);
                    
                    $("#location_status").val(locations[i][7]);
                   


                    $("#form").show();
                    infowindow.setContent(marker.html);
                    infowindow.open(map, marker);
                }
            })(marker, i));
        }
    }

 


</script>


<div style="display: none" id="form"  >
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.6/css/materialize.min.css">    

<div class="container" style="background-color: #61bc47;">
    <div class="card">
      <div class="card-image waves-effect waves-block waves-light">
 
      

    
  
     
  
            <h5>Parking ID:</h5>
            <textarea disabled id='email' placeholder='email'></textarea>
    

       
      
            <h5>Lat:</h5>
           <textarea disabled id='phone' placeholder='phone'></textarea>

           
           <h5>Lng:</h5>
           <textarea disabled id='city' placeholder='city'></textarea>

           <h5>Vehicle Number Plate:</h5>
           <textarea disabled id='category' placeholder='category'></textarea>

           <h5>Name</h5>
           <textarea disabled id='amount' placeholder='Slot'></textarea>

           <h5>Phone Number</h5>
           <textarea disabled id='area' placeholder='area'></textarea>
           
        <h5>In Time</h5>
           <textarea disabled id='sky1' placeholder='area'></textarea>
        
         <h5>Status</h5>
           <textarea disabled id='location_status' placeholder='area'></textarea>

        


           
       
        
       
      </div>
     
    </div>
  </div>
</div>
  <style>
             
             .myButton {
        box-shadow: 0px 10px 14px -7px #3e7327;
        background-color:#77b55a;
        border-radius:4px;
        border:1px solid #4b8f29;
        display:inline-block;
        cursor:pointer;
        color:#ffffff;
        font-family:Arial;
        font-size:13px;
        font-weight:bold;
        padding:12px 28px;
        text-decoration:none;
        text-shadow:0px 1px 0px #5b8a3c;
      }
      .myButton:hover {
        background-color:#72b352;
      }
      .myButton:active {
        position:relative;
        top:1px;
      }
      
      
      
             </style>
      
        
        

 
    
</div>
<script async defer
src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAWQSUeU7-btti27pbUtAc1ludM_fnoNEg&map_ids=8271b18eb74b62e4&callback=initMap">


</script>
<style>

textarea{

border: none;
background-color: #fff;
font-size: 30px;
color: #000;


}






</style>