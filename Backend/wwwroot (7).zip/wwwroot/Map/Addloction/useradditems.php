<?php

include_once('additems.php'); 

 

?>

<!DOCTYPE html>
<html>
<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">
	<title></title>

	<!-- Site favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="image/logo.png">
	<link rel="icon" type="image/png" sizes="32x32" href="image/logo.png">
	<link rel="icon" type="image/png" sizes="16x16" href="image/logo.png">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="src/plugins/jquery-steps/jquery.steps.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">


	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-119386393-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'UA-119386393-1');
	</script>


</head>
<body>
	
	<form action="additems.php" method="post">
	

	<div class="mobile-menu-overlay"></div>




									<div class="col-md-6">
										<div class="form-group">

										<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAWQSUeU7-btti27pbUtAc1ludM_fnoNEg&callback=initMap&libraries=&v=weekly"
      defer
    ></script>
											
										<div id="map" style="width:500px;height:400px; background:grey"></div>

						<script>




function initMap() {
  // The location of Uluru
  var uluru = { lat: 6.785277702704765, lng: 80.11392854687506 };

  
  // The map, centered at Uluru
  var map = new google.maps.Map(document.getElementById("map"), {
    zoom: 5,
	center: uluru,
	draggable:true
		
  });

  var marker = new google.maps.Marker({
    position: uluru,
	map: map,
	draggable:true

	
  });

  marker.setMap(map);
  
  
  map.addListener("center_changed", () => {
    // 3 seconds after the center of the map has changed, pan back to the
    // marker.
    window.setTimeout(() => {
      map.panTo(marker.getPosition());
    }, 3000);
  });

  marker.addListener("click", () => {
    map.setZoom(8);
	map.setCenter(marker.getPosition());
	console.log( 'i am dragged' );


    var lat = marker.getPosition().lat();
	var long = marker.getPosition().lng();

	console.log( lat );
	console.log( long );

	document.getElementById("latitude").value = lat;
	document.getElementById("loge").value = long;

  });
     

 
  // The marker, positioned at Uluru
  













  
}









						</script>
	


	                         
											
										</div>
									</div>

									<div class="col-md-6">




										<div class="form-group">
											<label>latitude :</label>
											<input type="text"  id="latitude" name="lat">
											<input type="text"  id="loge"  name="lng">
										</div>

                                       <div class="form-group">
											<label>Parking ID:</label>
											<input type="text"  id="latitude" name="pid">
											<label>Name:</label>
											<input type="text"  id="loge"  name="pname">
										</div>

 <div class="form-group">
											<label>Slot:</label>
											<input type="text"  id="latitude" name="lslot">

											<label>Map Link:</label>
											<input type="text"  id="latitude" name="map">
											
										</div>





									</div>

									
<input type="submit"  name="submit" >


								</div>
							</section>
							<!-- Step 4 -->
							
						
					</div>
				</div>

			

			
				</form>
				<!-- success Popup html End -->
			</div>
			
		</div>
	</div>
	<!-- js -->
	<script src="vendors/scripts/core.js"></script>
	<script src="vendors/scripts/script.min.js"></script>
	<script src="vendors/scripts/process.js"></script>
	<script src="vendors/scripts/layout-settings.js"></script>
	<script src="src/plugins/jquery-steps/jquery.steps.js"></script>
	<script src="vendors/scripts/steps-setting.js"></script>
	


	





</body>
</html>