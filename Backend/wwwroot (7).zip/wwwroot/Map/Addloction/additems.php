<?php
session_start();


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "smartparking";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



if (isset($_POST['submit'])) {   


    //to check if the form was submitted



    $pid= $_POST['pid'];
    $pname =$_POST["pname"];
    $lslot =$_POST["lslot"];
    $map =$_POST["map"];
 
    $lat =$_POST["lat"];
    $lng =$_POST["lng"];



    

    

    


$sql = "INSERT INTO location(pid,pname,lat,lng,slot,link) VALUES('$pid','$pname','$lat','$lng','$lslot', '$map' )";

if(mysqli_query($conn, $sql)){
    echo "Records added successfully.";
 
   
                
                





        
    }

       else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}






$conn->close();








   


  
}



?>