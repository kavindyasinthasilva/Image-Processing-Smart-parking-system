<?php
session_start();


// Create connection
$conn = mysqli_init();


mysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);


// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


















if (isset($_POST['submit'])) {   


    //to check if the form was submitted



    $pid= $_POST['pid'];
    $pname =$_POST["vid"];
    $phone =$_POST["phone"];
    $link =$_POST["link"];
 
    $lat =$_POST["lat"];
    $lng =$_POST["lng"];

     $uname =$_POST["uname"];
     
     
$sa =$_POST["sa"];
    
    
    $snew = $sa +1;

    $s = 0;

    


$sql = "INSERT INTO oder(pid,vid,uanme,phone,lat,lng,status) VALUES('$pid','$pname','$uname','$phone','$lat', '$lng',' $s' )";

if(mysqli_query($conn, $sql)){
    
 
   
       $sql1 = "UPDATE location SET avilableslot =$snew  WHERE pid=$pid";

if(mysqli_query($conn, $sql1)){
    
    
     header("Location:thank_you.php?link=$link");



            
             
}

   else{





   }          
                





        
    }

       else{
    
}






$conn->close();








   


  
}



?>