<?php
/**
 * @author Ravi Tamada
 * @link http://www.androidhive.info/2012/01/android-login-and-registration-with-php-mysql-and-sqlite/ Complete tutorial
 */

class DB_Connect {
 

    // Connecting to database
    public function connect() {
        require_once 'include/Config.php';
        
        // Connecting to mysql database
        $conn = mysqli_init();



        mysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);

if (!$conn) {
    die('Not connected : ' . mysqli_connect_error());
}
        
        // return database handler
        return conn;
    }
}

?>
