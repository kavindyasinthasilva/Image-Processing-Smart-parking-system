Visit the below endpoints<br/>

Login:<br/>
http://YOUR_MACHINE_IP/android_login_api/login.php<br/><br/>

Registration:<br/>
http://YOUR_MACHINE_IP/android_login_api/register.php<br/><br/>


