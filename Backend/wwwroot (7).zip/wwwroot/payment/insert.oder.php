<?php
session_start();


// Create connection
$conn = mysqli_init();


mysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);


// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


















if (isset($_POST['submit'])) {   


    //to check if the form was submitted



    $pid= $_POST['pid'];
    
    $phone =$_POST["phone"];
    $card =$_POST["card"];
 
    $cvv =$_POST["cvv"];
    $exp =$_POST["exp"];

     $time =$_POST["time"];
     
     $price =$_POST["price"];


    $price2="+94"+$price;


$sql = "INSERT INTO payment(vid,card,cvv,exp,price) VALUES('$pid',' $card',' $cvv','$exp','$price' )";

if(mysqli_query($conn, $sql)){
    
 
   
       $sql1 = "UPDATE oder SET outtime =' $time',status ='1'  WHERE vid='$pid'";
       

if(mysqli_query($conn, $sql1)){
    
    
     header("Location:https://smartparking-38e4c.web.app/public/?phone=$price2");



            
             
}

   else{





   }          
                





        
    }

       else{
    
}






$conn->close();








   


  
}



?>