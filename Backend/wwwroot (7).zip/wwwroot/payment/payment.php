<!doctype html>
<html lang="en" class="h-100">
    

    
    
    <?php
					   $pid =$_GET['pid'];	
					   $username =$_GET['username'];	
							
							$conn=mysqli_init();







mysqli_ssl_set($conn,NULL,NULL, null, NULL, NULL);



mysqli_real_connect($conn,'smartparkingst.mysql.database.azure.com', 'nsbmply@smartparkingst', '@Wushu1999', 'smartparking', 3306, NULL, MYSQLI_CLIENT_SSL);






if (!$conn) {
    die('Not connected : ' . mysqli_connect_error());
}
	

									$sql = "SELECT * FROM  oder  where pid= '$pid' and uanme = '$username' and status='0'  ";
									$result = mysqli_query($conn, $sql) or die( mysqli_error($conn));
 
 
	 
									while($res = mysqli_fetch_array($result)) {         
						
								$name =    $res['uanme'];
								$phone =	 $res['phone'] ;
								$vid =	 $res['vid'] ;
					         	$intime =	 $res['intime'] ;
					         	$status =	 $res['status'] ;
					         
									
									 

									   }
									   
									  
				  
                                     
     ?>



<!-- Mirrored from maxartkiller.com/website/finwallapp/HTML/payment.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 May 2021 16:34:27 GMT -->
<head onload="myFunction()">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="generator" content="">
    <title>Finwallapp - Mobile HTML template</title>

    <!-- manifest meta -->
    <meta name="apple-mobile-web-app-capable" content="yes">

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="img/favicon180.png" sizes="180x180">
    <link rel="icon" href="img/favicon32.png" sizes="32x32" type="image/png">
    <link rel="icon" href="img/favicon16.png" sizes="16x16" type="image/png">

    <!-- Material icons-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&amp;display=swap" rel="stylesheet">

    <!-- swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet" id="style">
</head>

<body class="body-scroll d-flex flex-column h-100 menu-overlay" style="background: #ffb74d ;color:#ffb74d " >
    <!-- screen loader -->
    <div class="container-fluid h-100 loader-display">
        <div class="row h-100">
            <div class="align-self-center col">
                <div class="logo-loading">
                    <div class="icon icon-100 mb-4 rounded-circle">
                        <img src=" icon.png" alt="" class="w-100">
                    </div>
                    <h4 class="text-default">Smartparking</h4>
                    <p class="text-secondary">NSBM</p>
                    <div class="loader-ellipsis">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!-- Begin page content -->
    <main class="flex-shrink-0 main" style="background: #ffb74d ;color:#ffb74d " >
        <!-- Fixed navbar -->
        <header class="header" style="background: #ffb74d ;color:#ffb74d ">
            <div class="row">
                <div class="col-auto px-0">
                    <button class="btn btn-40 btn-link back-btn" type="button">
                        <span class="material-icons">keyboard_arrow_left</span>
                    </button>
                </div>
                <div class="text-left col align-self-center">
                </div>
                <div class="ml-auto col-auto">
                    <a href="profile.html" class="avatar avatar-30 shadow-sm rounded-circle ml-2">
                        <figure class="m-0 background">
                            
                        </figure>
                    </a>
                </div>
            </div>
        </header>
        
        

<script type="text/javascript">
	


var currentdate = new Date(); 
var datetime =   currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();

document.write(datetime);

function myFunction() { 

document.getElementById("time").value ="sdf";
}

</script>
  
        
        <?php 
        
        $currentDateTime = date('H:i:s');


         $newtime = $currentDateTime ;
         
         $t = (string) $newtime;
         
     
    
  $time1 = $intime ;
  $time2 = $currentDateTim ;
  $time1 = explode(':',$time1);
  $time2 = explode(':',$time2);
  $hours1 = $time1[0];
  $hours2 = $time2[0];
  $mins1 = $time1[1];
  $mins2 = $time2[1];
  $hours = $hours2 - $hours1;
  $mins = 0;
  if($hours < 0)
  {
    $hours = 24 + $hours;
  }
  if($mins2 >= $mins1) {
        $mins = $mins2 - $mins1;
    }
    else {
      $mins = ($mins2 + 60) - $mins1;
      $hours--;
    }
    if($mins < 9)
    {
      $mins = str_pad($mins, 2, '0', STR_PAD_LEFT);
    }
    if($hours < 9)
    {
      $hours =str_pad($hours, 2, '0', STR_PAD_LEFT);
    }
echo $hours.':'.$mins;


     
       
if($hours >= 3)

{
    
    
    $hours =100;
    
    
}
   if($hours >= 7)

{
    
    
    $hours =500;
    
    
}  

 if($hours >= 8)

{
    
    

    
    
}  





?>

        <!-- page content start -->
        <div class="container mt-3 mb-4 text-center">
            <h2 class="text-white">RS <?php echo $hours; ?> /-</h2>
            <p class="text-white mb-4">Total Balance </p>



            
            
        </div>
     
        <div class="main-container" style="background: #ffb74d" onload="myFunction()">
            <div class="container">
                <div class="card mb-4">
                    <div class="card-header">
                    </div>
                    <div class="card-body">
                        <form action="insert.oder.php" method = "POST">
                            <div class="form-group">
                                <label for="exampleFormControlInput1">Vehicle Number Plate</label>
                                <input type="text" class="form-control is-valid" id="exampleFormControlInput1" placeholder="Parking ID" value="<?php echo $vid ?>" name="pid">
                                <p class="form-text valid-feedback">This is Automatic Adding</p>
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlInput2">Phone Number</label>
                                <input type="text" class="form-control is-invalid" id="exampleFormControlInput2" placeholder="(+94)072 344 5564" name="phone" value="<?php echo $phone ?> ">
                                <p class="form-text invalid-feedback">(+94)072 344 5564</p>
                            </div>
                             <div class="form-group">
                                <label for="exampleFormControlInput2">In Time - <?php echo $intime  ?></label>
                            </div>
                              <div class="form-group">
                                <label for="exampleFormControlInput2">Credit Card Vumbers</label>
                                <input type="text" class="form-control is-invalid" id="exampleFormControlInput2" placeholder="9454523244353435" name="card">
                                
                            </div>
                            
                             <div class="form-group">
                                <label for="exampleFormControlInput2">CVV</label>
                                <input type="text" class="form-control is-invalid" id="exampleFormControlInput2" placeholder="CVV" name="cvv">
                                
                            </div>
                            
                             <div class="form-group">
                                <label for="exampleFormControlInput2">EXP</label>
                                <input type="text" class="form-control is-invalid" id="exampleFormControlInput2" placeholder="EXP" name="exp">
                                
                            </div>
                            
         <input type="text" value="<?php  echo $hours;?>" name="price">
          <input type="text" value="<?php echo  $currentDateTime; ?>" name="time">
         
         
          

            <div class="col" style="background: #ffb74d">
                <input type="submit" name="submit" class="btn btn-default rounded btn-block" style="background: #ffb74d">
            </div> 
        
        
        
        
        
        
    </main>
    
    


    <!-- Required jquery and libraries -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- cookie js -->
    <script src="js/jquery.cookie.js"></script>

    <!-- Swiper slider  js-->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- Customized jquery file  -->
    <script src="js/main.js"></script>
    <script src="js/color-scheme-demo.js"></script>


    <!-- page level custom script -->
    <script src="js/app.js"></script>
    
    
</body>


<!-- Mirrored from maxartkiller.com/website/finwallapp/HTML/payment.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 May 2021 16:34:27 GMT -->
</html>
